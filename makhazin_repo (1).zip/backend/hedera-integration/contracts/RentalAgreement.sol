// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract RentalAgreement {
    address public owner;
    address public renter;
    uint public listingId;
    uint public start;
    uint public end;
    uint public deposit;
    bool public active;

    event AgreementCreated(uint listingId, address renter, uint start, uint end);
    event DepositPaid(address payer, uint amount);
    event Started();
    event Ended();
    event DisputeRaised(string reason);
    event FundsReleased();

    constructor(uint _listingId, address _renter, uint _start, uint _end, uint _deposit) {
        owner = msg.sender;
        listingId = _listingId;
        renter = _renter;
        start = _start;
        end = _end;
        deposit = _deposit;
        active = true;
        emit AgreementCreated(listingId, renter, start, end);
    }

    function payDeposit() public payable {
        require(msg.value == deposit, "Deposit must equal required amount");
        emit DepositPaid(msg.sender, msg.value);
    }

    function markStarted() public {
        require(msg.sender == owner || msg.sender == renter, "Not authorized");
        emit Started();
    }

    function markEnded() public {
        require(msg.sender == owner || msg.sender == renter, "Not authorized");
        active = false;
        emit Ended();
    }

    function raiseDispute(string memory reason) public {
        emit DisputeRaised(reason);
    }

    function releaseFunds() public {
        // simple release: send deposit back to renter (placeholder)
        payable(renter).transfer(address(this).balance);
        emit FundsReleased();
    }
}
