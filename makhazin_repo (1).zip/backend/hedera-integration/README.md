# Hedera Integration Service - README

This service handles all interactions between Makhazin backend and Hedera network:
- Deploy / interact with rental smart contracts
- Publish audit events to an HCS topic
- Manage HTS tokens for deposits and payments
- Mirror node listener to sync events back to application DB

## Requirements
- Java 17, Maven
- Hedera Java SDK
- Access to Hedera testnet account (operatorId, operatorKey)

## Quick start (local)
1. Copy `.env.example` to `.env` and fill:
   - HEDERA_OPERATOR_ID=0.0.x
   - HEDERA_OPERATOR_KEY=302e...
   - HEDERA_NETWORK=testnet
   - HCS_TOPIC_ID=0.0.xxx
2. Build:
   ```bash
   cd backend/hedera-integration
   mvn clean package
   ```
3. Run:
   ```bash
   java -jar target/hedera-integration-0.1.jar
   ```

## Files included
- `src/main/java/.../HederaClient.java` (skeleton)
- `contracts/` (Solidity templates)
- `scripts/` (minting / test flows)

