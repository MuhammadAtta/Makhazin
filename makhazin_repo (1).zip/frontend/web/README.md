# Frontend (Web) - Next.js (placeholder)

This folder will contain a Next.js app with:
- pages: /, /listing/[id], /dashboard, /bookings
- integrations: call backend APIs, display Hedera tx ids, show audit timeline

Quick start (once implemented):
```bash
cd frontend/web
npm install
npm run dev
```
